/***************************************************************************
                          main.c  -  description
                             -------------------
    begin                : mar ene 11 09:26:58 CET 2005
    copyright            : (C) 2005 by Augusto Beiro
    email                : abeiro@activasistemas.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#ifdef HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>

#include "global.h"

#include "anlz.h"
#include "argparse.h"
#include "logic.h"

#include "gui_plugs.h"

/* Some defaults values */
int _N_DRIVES = 0;
char _SELECTED_DRIVE[256];
char *_DRIVE_LIST[25];
char *_DRIVE_LIST_NAMES[25];
int _N_SEL_DRIVE = -1;
char _DISK_STATUS = DISK_UNKNOWN;

char _BE_VERBOSE = 0;
char _BE_INTERACTIVE = 0;

long long int _LAYOUT[10]={0,0,0,0,0,0,0,0,0,0};

plugin_info *plugins = NULL;
int numero_plugins = 0;

int main(int argc, char *argv[])
{
    const char *locale;
    const char *textdomaindir;

    /* Int support : Soporte Internacional */
    //*******************************

    locale = setlocale(LC_ALL, "");
    if (!locale) {
        locale = setlocale(LC_ALL, NULL);
        xprint("Failed to set locale, using default '%s'.\n", locale);

    } else {
        xprint("Using locale '%s'.\n", locale);

    }

    textdomain("peez2");
    textdomaindir = bindtextdomain("peez2", NULL);
    xprint("Using domain dir '%s'.\n", textdomaindir);
    //*********************************

    printf("%s %s %s %s\n", _P_APPNAME, _i18n("Version"), _P_VERSION,__DATE__);

    /* 1st step : Primer Paso */
    /* Parse args */
    _SELECTED_DRIVE[0] = '\0';
    if (!_p_parse_args(argc, argv))
        return -1;

    /* Search for gui plugs */
    if (!Dgui_plug_search(argv)) {
        printf("%s\n", _i18n("No GUI plug-ins found"));
        return 0;
    }

    /* 2nd step : Segundo Paso */
    /* Analisis de discos */
    if (!_p_anlz())
        return -1;

    /* 3rd step : Tercer Paso */
    /* Logica y toma de decisiones */
    if (!_p_logic())
        return -1;

    if (_APP_ACTION == APP_ACTION_WIZARD)
        _p_show_actions();
    
    return 0;
}
