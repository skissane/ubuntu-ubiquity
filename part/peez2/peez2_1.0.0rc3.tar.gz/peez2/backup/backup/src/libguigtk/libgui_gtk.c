/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <config.h>
#include <gtk/gtk.h>
#include <stdio.h>
#include <glib.h>

char local_res[2048];

const char nombre[] = "GTK front-end";
const char autor[] = "Augusto Beiro Salanova";
const char info[] = "GTK front-end";
const int version[3] = { 0, 0, 1 };
const int fecha[3] = { 31, 1, 2005 };
const char extension[] = "gtk";

/* Option select */
GtkWidget **option;
int n_options;
char *button_name[5] = { "Uno", "Dos", "Tres", "Cuatro", "Cinco" };
int selected = -1;

/* Progressbar vars */

GtkWidget *window1;
GtkWidget *fixed1;
GtkWidget *progressbar1;
GtkWidget *label1;
GMainLoop *loop_fe;

char init = 0;

extern char *mostrar_autor(void)
{
    return (char *) &autor[0];
}
extern char *mostrar_nombre(void)
{
    return (char *) &nombre[0];
}
extern char *mostrar_info(void)
{
    return (char *) &info[0];
}
extern int *mostrar_version(void)
{
    return (int *) &version[0];
}
extern int *mostrar_fecha(void)
{
    return (int *) &fecha[0];
}
extern char *mostrar_extension(void)
{
    return (char *) &extension[0];
}

void enter_callback(GtkWidget * widget, GtkWidget * entry_text)
{

    gchar *entry_text_dest;
    entry_text_dest = gtk_entry_get_text(GTK_ENTRY(entry_text));
    strcpy(local_res, entry_text_dest);
    gtk_main_quit();

}

void close_callback(GtkWidget * widget, GtkWidget * entry)
{

    gtk_main_quit();

}

extern int readline(char *orig, char *res)
{

    gtk_init(0, NULL);
    local_res[0] = '\0';

    /* Glade code */

    GtkWidget *window_main;
    GtkWidget *fixed1;
    GtkWidget *entry_text;
    GtkWidget *s_label;
    

    window_main = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_object_set_data(GTK_OBJECT(window_main), "window_main",
                        window_main);
    gtk_widget_set_usize(window_main, 394, 84);
    gtk_window_set_title(GTK_WINDOW(window_main), "--");
    gtk_window_set_position(GTK_WINDOW(window_main), GTK_WIN_POS_CENTER);
    gtk_window_set_default_size(GTK_WINDOW(window_main), 394, 84);
    gtk_window_set_policy(GTK_WINDOW(window_main), FALSE, FALSE, FALSE);

    fixed1 = gtk_fixed_new();
    gtk_widget_ref(fixed1);
    gtk_object_set_data_full(GTK_OBJECT(window_main), "fixed1", fixed1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(fixed1);
    gtk_container_add(GTK_CONTAINER(window_main), fixed1);
    gtk_widget_set_usize(fixed1, 394, 84);

    entry_text = gtk_entry_new();
    gtk_widget_ref(entry_text);
    gtk_object_set_data_full(GTK_OBJECT(window_main), "entry_text",
                             entry_text,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(entry_text);
    gtk_fixed_put(GTK_FIXED(fixed1), entry_text, 8, 40);
    gtk_widget_set_uposition(entry_text, 8, 40);
    gtk_widget_set_usize(entry_text, 376, 24);

    s_label = gtk_label_new("Prompt");
    gtk_widget_ref(s_label);
    gtk_object_set_data_full(GTK_OBJECT(window_main), "s_label", s_label,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(s_label);
    gtk_fixed_put(GTK_FIXED(fixed1), s_label, 8, 8);
    gtk_widget_set_uposition(s_label, 8, 8);
    gtk_widget_set_usize(s_label, 376, 24);
    gtk_label_set_justify(GTK_LABEL(s_label), GTK_JUSTIFY_LEFT);
    gtk_label_set_line_wrap(GTK_LABEL(s_label), TRUE);

    /* End of glade code */

    gtk_label_set_text(s_label, orig);

    gtk_signal_connect(GTK_OBJECT(entry_text), "activate",
                       GTK_SIGNAL_FUNC(enter_callback), entry_text);
    gtk_signal_connect(GTK_OBJECT(window_main), "destroy",
                       GTK_SIGNAL_FUNC(close_callback), window_main);

    gtk_widget_show_all(window_main);

    gtk_main();

    strcpy(res, local_res);

    return 1;

}

extern int progressbar(char *msg, float f)
{

    if (init == 0) {

        gtk_init(0, NULL);

        /* GLade code */

        window1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_object_set_data(GTK_OBJECT(window1), "window1", window1);
        gtk_container_set_border_width(GTK_CONTAINER(window1), 8);
        gtk_window_set_title(GTK_WINDOW(window1), "--");
        gtk_window_set_position(GTK_WINDOW(window1), GTK_WIN_POS_CENTER);
        gtk_window_set_policy(GTK_WINDOW(window1), FALSE, FALSE, FALSE);

        fixed1 = gtk_fixed_new();
        gtk_widget_ref(fixed1);
        gtk_object_set_data_full(GTK_OBJECT(window1), "fixed1", fixed1,
                                 (GtkDestroyNotify) gtk_widget_unref);
        gtk_widget_show(fixed1);
        gtk_container_add(GTK_CONTAINER(window1), fixed1);

        progressbar1 = gtk_progress_bar_new();
        gtk_widget_ref(progressbar1);
        gtk_object_set_data_full(GTK_OBJECT(window1), "progressbar1",
                                 progressbar1,
                                 (GtkDestroyNotify) gtk_widget_unref);
        gtk_widget_show(progressbar1);
        gtk_fixed_put(GTK_FIXED(fixed1), progressbar1, 0, 24);
        gtk_widget_set_uposition(progressbar1, 0, 24);
        gtk_widget_set_usize(progressbar1, 518, 24);

        label1 = gtk_label_new("label1");

        gtk_widget_ref(label1);
        gtk_object_set_data_full(GTK_OBJECT(window1), "label1", label1,
                                 (GtkDestroyNotify) gtk_widget_unref);
        gtk_widget_show(label1);
        gtk_fixed_put(GTK_FIXED(fixed1), label1, 0, 0);
        gtk_widget_set_uposition(label1, 0, 0);
        gtk_widget_set_usize(label1, 520, 16);
        gtk_label_set_justify(GTK_LABEL(label1), GTK_JUSTIFY_LEFT);

        /* End of glade code */

        gtk_label_set_text(label1, msg);

        gtk_widget_show_all(window1);
        //gtk_main ();
        loop_fe = g_main_new(TRUE);
        g_main_iteration(FALSE);

        init = 1;
    } else {

        if (f > 1) {

            gtk_widget_destroy(window1);
            g_main_iteration(FALSE);
            g_main_destroy(loop_fe);
            //printf("GTKFE: Destroyed dialog\n");
            init = 0;
            return 1;
        } else if (g_main_is_running(loop_fe) && (progressbar1 != NULL)) {
            gtk_progress_bar_update(GTK_PROGRESS_BAR(progressbar1), f);
            g_main_iteration(FALSE);
        }

    }
    return 1;
}

void show_option(GtkButton * button, gpointer user_data)
{
    int i;
    for (i = 0; i < n_options; i++) {

        if (gtk_toggle_button_get_active(option[i]))
            selected = i;
        //printf("%d\n", i);
    }

    gtk_main_quit();

}

extern select_option(int number, char **leyendas, char *prompt)
{

    GtkWidget *window2;
    GtkWidget *vbox1;
    GtkWidget *label1;
    GSList *option_group = NULL;
    GtkWidget *radiobutton3;
    GtkWidget *radiobutton4;
    GtkWidget *fixed1;
    GtkWidget *ok;
    int i;

    gtk_init(0, NULL);
    n_options = number;

    window2 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_object_set_data(GTK_OBJECT(window2), "window2", window2);
    gtk_window_set_title(GTK_WINDOW(window2), "--");

    vbox1 = gtk_vbox_new(FALSE, 0);
    gtk_widget_ref(vbox1);
    gtk_object_set_data_full(GTK_OBJECT(window2), "vbox1", vbox1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(vbox1);
    gtk_container_add(GTK_CONTAINER(window2), vbox1);

    label1 = gtk_label_new(prompt);
    gtk_widget_ref(label1);
    gtk_object_set_data_full(GTK_OBJECT(window2), "label1", label1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(label1);
    gtk_box_pack_start(GTK_BOX(vbox1), label1, TRUE, TRUE, 0);

    option = (GtkWidget **) malloc(n_options * sizeof(GtkWidget **));
    for (i = 0; i < n_options; i++) {
        option[i] =
            gtk_radio_button_new_with_label(option_group, leyendas[i]);
        option_group = gtk_radio_button_group(GTK_RADIO_BUTTON(option[i]));
        gtk_widget_ref(option[i]);
        gtk_object_set_data_full(GTK_OBJECT(window2), leyendas[i],
                                 option[i],
                                 (GtkDestroyNotify) gtk_widget_unref);
        gtk_widget_show(option[i]);
        gtk_box_pack_start(GTK_BOX(vbox1), option[i], TRUE, TRUE, 0);
    }

    fixed1 = gtk_fixed_new();
    gtk_widget_ref(fixed1);
    gtk_object_set_data_full(GTK_OBJECT(window2), "fixed1", fixed1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(fixed1);
    gtk_box_pack_start(GTK_BOX(vbox1), fixed1, FALSE, FALSE, 0);

    ok = gtk_button_new_with_label("Ok");
    gtk_widget_ref(ok);
    gtk_object_set_data_full(GTK_OBJECT(window2), "ok", ok,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(ok);
    gtk_fixed_put(GTK_FIXED(fixed1), ok, 256, 24);
    gtk_widget_set_uposition(ok, 256, 24);
    gtk_widget_set_usize(ok, 47, 22);
    gtk_container_set_border_width(GTK_CONTAINER(ok), 2);

    gtk_signal_connect(GTK_OBJECT(ok), "clicked",
                       GTK_SIGNAL_FUNC(show_option), NULL);
    gtk_signal_connect(GTK_OBJECT(window2), "destroy",
                       GTK_SIGNAL_FUNC(show_option), NULL);
    gtk_set_locale();

    gtk_widget_show(window2);
    gtk_main();
    gtk_widget_hide_all(window2);

    return (selected + 1);

}

extern long long int limit(long long int min, long long max, char *prompt)
{
    GtkWidget *lwindow1;
    GtkWidget *lvbox1;
    GtkWidget *llabel1;
    GtkWidget *lvbox2;
    GtkWidget *hseparator1;
    GtkWidget *hscale1;
    GtkWidget *lhbox1;
    GtkWidget *lbutton1;
    GtkWidget *fixed1;

    GtkAdjustment *hack;

    long long int res;

    /*
       Init Glade Code
     */

    gtk_init(0, NULL);

    lwindow1 = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_object_set_data(GTK_OBJECT(lwindow1), "lwindow1", lwindow1);
    gtk_widget_set_usize(lwindow1, 376, 115);
    gtk_window_set_title(GTK_WINDOW(lwindow1), prompt);
    gtk_window_set_position(GTK_WINDOW(lwindow1), GTK_WIN_POS_CENTER);

    lvbox1 = gtk_vbox_new(FALSE, 0);
    gtk_widget_ref(lvbox1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "lvbox1", lvbox1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(lvbox1);
    gtk_container_add(GTK_CONTAINER(lwindow1), lvbox1);
    gtk_container_set_border_width(GTK_CONTAINER(lvbox1), 0);

    llabel1 = gtk_label_new(prompt);
    gtk_widget_ref(llabel1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "llabel1", llabel1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(llabel1);
    gtk_box_pack_start(GTK_BOX(lvbox1), llabel1, FALSE, FALSE, 0);
    gtk_misc_set_padding(GTK_MISC(llabel1), 14, 17);

    lvbox2 = gtk_vbox_new(FALSE, 4);
    gtk_widget_ref(lvbox2);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "lvbox2", lvbox2,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(lvbox2);
    gtk_box_pack_start(GTK_BOX(lvbox1), lvbox2, TRUE, TRUE, 0);

    hseparator1 = gtk_hseparator_new();
    gtk_widget_ref(hseparator1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "hseparator1",
                             hseparator1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(hseparator1);
    gtk_box_pack_start(GTK_BOX(lvbox2), hseparator1, FALSE, FALSE, 0);

    hack = GTK_ADJUSTMENT(gtk_adjustment_new(min, min, max, 1024, 0, 0));
    hscale1 = gtk_hscale_new(hack);
    gtk_widget_ref(hscale1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "hscale1", hscale1,
                             (GtkDestroyNotify) gtk_widget_unref);

    gtk_widget_show(hscale1);
    gtk_box_pack_start(GTK_BOX(lvbox2), hscale1, TRUE, TRUE, 0);
    gtk_scale_set_digits(GTK_SCALE(hscale1), 0);
    gtk_range_set_update_policy(GTK_RANGE(hscale1), GTK_UPDATE_DELAYED);

    lhbox1 = gtk_hbox_new(FALSE, 0);
    gtk_widget_ref(lhbox1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "lhbox1", lhbox1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(lhbox1);
    gtk_box_pack_end(GTK_BOX(lvbox2), lhbox1, FALSE, FALSE, 0);

    fixed1 = gtk_fixed_new();
    gtk_widget_ref(fixed1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "fixed1", fixed1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(fixed1);
    gtk_box_pack_start(GTK_BOX(lhbox1), fixed1, TRUE, TRUE, 0);

    lbutton1 = gtk_button_new_with_label("Ok");
    gtk_widget_ref(lbutton1);
    gtk_object_set_data_full(GTK_OBJECT(lwindow1), "lbutton1", lbutton1,
                             (GtkDestroyNotify) gtk_widget_unref);
    gtk_widget_show(lbutton1);
    gtk_box_pack_start(GTK_BOX(lhbox1), lbutton1, FALSE, FALSE, 0);
    gtk_widget_set_usize(lbutton1, 59, 26);
    gtk_container_set_border_width(GTK_CONTAINER(lbutton1), 2);

    gtk_signal_connect(GTK_OBJECT(lbutton1), "clicked",
                       GTK_SIGNAL_FUNC(gtk_main_quit), NULL);

    /* END Glade Code */

    gtk_widget_show(lwindow1);
    gtk_main();
    gtk_widget_hide_all(lwindow1);

    res = (long long int) hack->value;

    return res;
}
