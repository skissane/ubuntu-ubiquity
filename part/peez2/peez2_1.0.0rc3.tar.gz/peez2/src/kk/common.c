/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdlib.h>
#include <stdarg.h>
#include <stdio.h>

#include "global.h"

int _p_cFlag(char flag)
{

    if ((flag & _DISK_STATUS) == flag)
	return 1;
    else
	return 0;

}

int _p_cAction(char flag, char alternative)
{

    if ((flag & alternative) == flag)
	return 1;
    else
	return 0;

}

void xprint(const char *fmt, ...) __attribute__ ((format(xprint, 1, 2)));
void xprint(const char *fmt, ...)
{
    va_list ap;

    va_start(ap, fmt);
    if (_BE_VERBOSE == 1)
	vfprintf(stdout, fmt, ap);
    va_end(ap);
    fflush(stdout);
}

void xfprint(const char *fmt, ...) __attribute__ ((format(xfprint, 1, 2)));
void xfprint(const char *fmt, ...)
{
    va_list ap;
    static FILE *OUT_FILE_POINTER;

    if (OUT_FILE == 1) {
	OUT_FILE_POINTER = fopen(OUT_FILE_NAME, "w");
	if (!OUT_FILE_POINTER)
	    xprint("%s %s\n", OUT_FILE_NAME, _i18n("..opening failed"));
	OUT_FILE = 2;
    }

    va_start(ap, fmt);
    if (OUT_FILE_POINTER)
	vfprintf(OUT_FILE_POINTER, fmt, ap);
    else
	vfprintf(stdout, fmt, ap);
    va_end(ap);
    fflush(stdout);
}

char *unix_device_translate(char *major, int minor)
{

    char *buffer;

    buffer = (char *) malloc(1024);

    switch (minor) {
    case 1:
	strcpy(buffer, _i18n("Part 1"));
	break;
    case 2:
	strcpy(buffer, _i18n("Part 2"));
	break;
    case 3:
	strcpy(buffer, _i18n("Part 3"));
	break;
    case 4:
	strcpy(buffer, _i18n("Part 4"));
	break;
    default:

	sprintf(buffer, "%s %d", _i18n("Part logical"), minor);
	break;
    }

    if (strcmp("/dev/hda", major) == 0)
	strcat(buffer, _i18n(" IDE Prim. Master"));
    else if (strcmp("/dev/hdb", major) == 0)
	strcat(buffer, _i18n(" IDE Prim. Slave"));
    else if (strcmp("/dev/hdc", major) == 0)
	strcat(buffer, _i18n(" IDE Sec. Master"));
    else if (strcmp("/dev/hdd", major) == 0)
	strcat(buffer, _i18n(" IDE Sec. Slave"));
    else
	strcpy(buffer, _i18n(" on SCSI/SATA/USB Drive"));

    return buffer;

}

char *unix_device_name(char *major, int minor)
{

    char *buffer;

    buffer = (char *) malloc(64);
    sprintf(buffer, "%s%d", major, minor);
    return buffer;

}
