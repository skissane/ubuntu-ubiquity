/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <unistd.h>

#include <dlfcn.h>

#include "gui_plugs.h"
#include "global.h"

void *hDll;
inline void *dlopen2(char *fich)
{
    return (void *) dlopen(fich, RTLD_LAZY | RTLD_GLOBAL);
}

#define DloadDLL dlopen2
#define DloadFunction dlsym
#define DcloseDLL dlclose

typedef char *(*DLLCHAR) (void);
typedef int *(*DLLINT) (void);
typedef int (*DLL_READLINE) (char *, char *);
typedef int (*DLL_GETININTERVAL) (long long int, long long int, char *);
typedef int (*DLL_PROGRESSBAR) (char *, float);
typedef int (*DLL_READOPTION) (int, char **, char *);

char **extensiones;
int n_plugs;
int n_plugin = -1;
int def_plugin = -1;		// Id for SIO

int Dgui_plug_search(char **argv)
{

    xprint("%s\n", _i18n("Looking for gui plugins"));

    if (Dsearch_plugs(NULL, plugins) != 1) {
	return 0;

    }

    return 1;

}

int Dsearch_plugs(char *dir, plugin_info * plug_tag)
{

    void *libc;
    int *tmp;
    char fich_dll[1024];
    struct dirent *lista_nombres;
    DIR *dir_h;
    int n_plug_tag = 0;

    char front_ends[4][256] = {
	"libguisio.so",
	//"libguigtk.so",
	//"libguigtk2.so",
	//"libguincr.so",
	//"/usr/lib/peez2/libguikde.so",
	NULL
    };
    int n_front_ends = 1;

    char *current = NULL;
    int n_cur = 0;
    /* Funciones a importar de la librer�a din�mica */

    DLLCHAR mostrar_nombre;
    DLLCHAR mostrar_autor;
    DLLCHAR mostrar_info;
    DLLINT mostrar_fecha;
    DLLINT mostrar_version;
    DLLCHAR mostrar_extension;

    n_cur = 0;
    current = &front_ends[n_cur][0];
    while (n_cur < n_front_ends) {
	xprint("# PLUG: %s\n", current);
	hDll = DloadDLL(current);

	if (hDll != NULL) {

	    mostrar_nombre =
		(DLLCHAR) DloadFunction(hDll, "mostrar_nombre");
	    xprint("# %s\n", (*mostrar_nombre) ());
	    mostrar_autor = (DLLCHAR) DloadFunction(hDll, "mostrar_autor");
	    xprint("# %s\n", (*mostrar_autor) ());
	    mostrar_info = (DLLCHAR) DloadFunction(hDll, "mostrar_info");
	    xprint("# %s\n", (*mostrar_info) ());
	    mostrar_version =
		(DLLINT) DloadFunction(hDll, "mostrar_version");
	    tmp = (*mostrar_version) ();
	    xprint("# Ver: %d.%d.%d  ", tmp[0], tmp[1], tmp[2]);
	    mostrar_fecha = (DLLINT) DloadFunction(hDll, "mostrar_fecha");
	    tmp = (*mostrar_fecha) ();
	    xprint("# %d/%d/%d\n", tmp[0], tmp[1], tmp[2]);
	    mostrar_extension =
		(DLLCHAR) DloadFunction(hDll, "mostrar_extension");
	    xprint("# Code: %s\n\n", (*mostrar_extension) ());
	    n_plug_tag++;
	    DcloseDLL(hDll);
	} else {
	    xprint("%s %s\n", current, dlerror());
	}
	n_cur++;
	current = &front_ends[n_cur][0];

    }

    plug_tag =
	(plugin_info *) malloc(sizeof(plugin_info) * (n_plug_tag + 1));
    extensiones = (char **) malloc(sizeof(char *) * (n_plug_tag + 2));
    /* Leemos el directorio de plug_tag por segunda vez */
    n_plug_tag = 0;
    n_cur = 0;
    current = &front_ends[n_cur][0];
    while (n_cur < n_front_ends) {
	hDll = DloadDLL(current);
	if (hDll != NULL) {
/*          
	  mostrar_nombre = (DLLCHAR) DloadFunction (hDll, "mostrar_nombre");
	  strcpy (plug_tag[n_plug_tag].nombre, (*mostrar_nombre) ());
	  mostrar_autor = (DLLCHAR) DloadFunction (hDll, "mostrar_autor");
	  strcpy (plug_tag[n_plug_tag].autor, (*mostrar_autor) ());
	  mostrar_info = (DLLCHAR) DloadFunction (hDll, "mostrar_info");
	  strcpy (plug_tag[n_plug_tag].info, (*mostrar_info) ());
	  mostrar_version = (DLLINT) DloadFunction (hDll, "mostrar_version");
	  tmp = (*mostrar_version) ();
	  plug_tag[n_plug_tag].version[0] = tmp[0];
	  plug_tag[n_plug_tag].version[1] = tmp[1];
	  plug_tag[n_plug_tag].version[2] = tmp[2];
	  
	  mostrar_version = (DLLINT) DloadFunction (hDll, "mostrar_fecha");
	  
	  tmp = (*mostrar_fecha) ();
	  
	  xprint("\nload\n");
	  
	  plug_tag[n_plug_tag].fecha[0] = tmp[0];
	  plug_tag[n_plug_tag].fecha[1] = tmp[1];
	  plug_tag[n_plug_tag].fecha[2] = tmp[2];
*/
	    mostrar_extension =
		(DLLCHAR) DloadFunction(hDll, "mostrar_extension");
	    strcpy(plug_tag[n_plug_tag].extension,
		   (*mostrar_extension) ());
	    strcpy(plug_tag[n_plug_tag].fich, current);
	    extensiones[n_plug_tag] =
		(char *) malloc(strlen(plug_tag[n_plug_tag].extension) +
				1);
	    strcpy(extensiones[n_plug_tag],
		   plug_tag[n_plug_tag].extension);

	    if (strcmp(extensiones[n_plug_tag], _FRONTEND_ID) == 0)
		n_plugin = n_plug_tag;

	    if (strcmp(extensiones[n_plug_tag], "sio") == 0)
		def_plugin = n_plug_tag;

	    n_plug_tag++;
	    DcloseDLL(hDll);

	} else {
	    xprint("%s %s\n", current, dlerror());
	}

	n_cur++;
	current = &front_ends[n_cur][0];
    }

    if (n_plugin < 0) {
	n_plugin = def_plugin;
	xprint("%s \n", _i18n("No valid frontend, selecting sio"));
    }
    if (n_plugin < 0) {
	xprint("%s \n",
	       _i18n("sio not found, bad installed app?.exiting"));
	return -1;
    }

    xprint("#%d %s \n", n_plug_tag, _i18n("plugins loaded"));
    extensiones[n_plug_tag] = NULL;

    plugins = plug_tag;
    numero_plugins = n_plug_tag;
    if (n_plug_tag == 0)
	return -1;
    else
	return 1;
}

int DreadLine(char *prompt, char *result)
{

    DLL_READLINE read_line_external;

    void *libc;
    int ok = 0;
    ;

    xprint("\nLoading dynamic plugin %s\n", plugins[n_plugin].fich);
    hDll = DloadDLL(plugins[n_plugin].fich);
    if (hDll == NULL) {
	xprint("%s %s ", plugins[n_plugin].fich, _i18n("Invalid"));
	return -1;
    } else
	xprint("%s %s\n", plugins[n_plugin].fich, _i18n("Loaded"));

    fflush(stdout);

    read_line_external = (DLL_READLINE) DloadFunction(hDll, "readline");
    if (read_line_external == NULL)
	xprint("(GUI) %s:%s\n", "readline", _i18n("No such function"));
    else
	ok = (*read_line_external) (prompt, result);

    DcloseDLL(hDll);

    return ok;

}

long long int Dget_in_interval(long long int min, long long int max,
			       char *prompt)
{

    DLL_GETININTERVAL read_line_external;

    void *libc;
    int ok = 0;
    ;

    if (min == max)
	return ((int) min);

    xprint("\n%s\n", plugins[n_plugin].fich);
    hDll = DloadDLL(plugins[n_plugin].fich);
    if (hDll == NULL) {
	xprint("%s %s ", plugins[n_plugin].fich, _i18n("Invalid"));
	return -1;
    } else
	xprint("%s %s\n", plugins[n_plugin].fich, _i18n("Loaded"));

    fflush(stdout);

    read_line_external = (DLL_READLINE) DloadFunction(hDll, "limit");
    if (read_line_external == NULL)
	xprint("(GUI) %s:%s\n", "readline", _i18n("No such function"));
    else
	ok = (*read_line_external) (min, max, prompt);

    DcloseDLL(hDll);

    if (ok<min)
    	ok=min;
    return ok;

}

int DprogressBar(char *msg, float percent)
{

    static DLL_PROGRESSBAR progress_bar_external = NULL;

    void *libc;
    int ok = 0;



    if (progress_bar_external == NULL) {

	xprint("\nLoading dynamic plugin %s\n", plugins[n_plugin].fich);
	hDll = DloadDLL(plugins[n_plugin].fich);
	if (hDll == NULL) {
	    xprint("%s %s ", plugins[n_plugin].fich, _i18n("Invalid"));
	    return -1;
	} else
	    xprint("%s %s\n", plugins[n_plugin].fich, _i18n("Loaded"));
	fflush(stdout);
	progress_bar_external =
	    (DLL_PROGRESSBAR) DloadFunction(hDll, "progressbar");
    }
    if (progress_bar_external == NULL)
	xprint("(GUI) %s:%s\n", "progressbar", _i18n("No such function"));
    else
	ok = (*progress_bar_external) (msg, percent);

    //DcloseDLL (hDll);

    return ok;

}

int DreadOption(int n_options, char **leyendas, char *prompt)
{

    DLL_READOPTION read_option_external;

    void *libc;
    int ok = 0;
    ;

    xprint("\n%s\n", plugins[n_plugin].fich);
    hDll = DloadDLL(plugins[n_plugin].fich);
    if (hDll == NULL) {
	xprint("%s %s ", plugins[n_plugin].fich, _i18n("Invalid"));
	return -1;
    } else
	xprint("%s %s\n", plugins[n_plugin].fich, _i18n("Loaded"));

    fflush(stdout);
    read_option_external =
	(DLL_READOPTION) DloadFunction(hDll, "select_option");
    if (read_option_external == NULL)
	xprint("(GUI) %s:%s\n", "select_option",
	       _i18n("No such function"));
    else
	ok = (*read_option_external) (n_options, leyendas, prompt);

    DcloseDLL(hDll);

    return ok;

}
