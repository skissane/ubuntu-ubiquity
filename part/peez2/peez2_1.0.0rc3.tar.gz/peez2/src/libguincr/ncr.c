/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>
#include <string.h>
#include <ncurses.h>

const char nombre[] = "ncurses Front-End";
const char autor[] = "Augusto Beiro Salanova";
const char info[] = "ncurses Front-End";
const int version[3] = { 0, 0, 1 };
const int fecha[3] = { 10, 3, 2005 };
const char extension[] = "ncr";

char sio_p_init = 0;

extern char *mostrar_autor(void)
{
    return (char *) &autor[0];
}
extern char *mostrar_nombre(void)
{
    return (char *) &nombre[0];
}
extern char *mostrar_info(void)
{
    return (char *) &info[0];
}
extern int *mostrar_version(void)
{
    return (int *) &version[0];
}
extern int *mostrar_fecha(void)
{
    return (int *) &fecha[0];
}
extern char *mostrar_extension(void)
{
    return (char *) &extension[0];
}

extern int readline(char *orig, char *res)
{

    int aux;

    initscr();

    WINDOW *win = newwin(LINES, COLS, 0, 0);

    aux = strlen(orig);
    mvwprintw(win, (LINES / 2), (COLS / 2) - (aux / 2), "%s", orig);
    box(win, 0, 0);

    mvwscanw(win, (LINES / 2) + 1, (COLS / 2) - (aux / 2), "%s", res);

    wrefresh(win);

    endwin();
    return (0);

}

extern int progressbar(char *msg, float f)
{
    if (f > 1) {
	printf("\b\b\b100\n");
	sio_p_init = 0;
	return 1;
    } else if (sio_p_init == 0) {
	printf("%s (%) %.3d", msg, (int) (f * 100));
	sio_p_init = 1;
    } else
	printf("\b\b\b%.3d", (int) (f * 100));

}

extern select_option(int number, char **leyendas, char *prompt)
{

    int i = 0;
    char c;
    int aux;

    initscr();

    WINDOW *win = newwin(LINES, COLS, 0, 0);

    aux = strlen(prompt);
    mvwprintw(win, (LINES / 2) - 2, (COLS / 2) - (aux / 2), "%s", prompt);
    for (i = 0; i < number; i++)
	aux = (strlen(leyendas[i]) > aux) ? strlen(leyendas[i]) : aux;

    for (i = 0; i < number; i++)
	mvwprintw(win, (LINES / 2) + i, (COLS / 2) - (aux / 2), "%d) %s",
		  i + 1, leyendas[i]);

    mvwprintw(win, (LINES / 2) + i, (COLS / 2), "");
    box(win, 0, 0);
    wrefresh(win);
    c = getchar();

    endwin();

    c = (c - 1 - 48);

    if ((c > -1) && (c < number))
	return (c + 1);
    else
	return 0;

}

extern long long int limit(long long int min, long long max, char *prompt)
{

    int i = 0;
    char c;
    long long int res = 0;
    int aux;

    initscr();

    WINDOW *win = newwin(LINES, COLS, 0, 0);

    aux = strlen(prompt);
    mvwprintw(win, (LINES / 2) - 2, (COLS / 2) - (aux / 2), "%s ", prompt);
    mvwprintw(win, (LINES / 2) - 1, (COLS / 2) - (aux / 2),
	      "[ %lld %lld ] ", min, max);
    box(win, 0, 0);

    wrefresh(win);

    mvwscanw(win, (LINES / 2) + 1, (COLS / 2) - (aux / 2), "%lld", &res);

    wrefresh(win);

    endwin();
    printf("-->DLL report %lld\n", res);
    if ((res >= min) && (res <= max))
	return res;
    else
	return 0;

}
