/***************************************************************************
                          anlz.c  -  description
                             -------------------
    begin                : mar ene 11 2005
    copyright            : (C) 2005 by Augusto Beiro
    email                : abeiro@activasistemas.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include "global.h"
#include "anlz.h"
#include "ntfsresize.h"
#include "gui_plugs.h"
#include <parted/timer.h>
#include <ext2fs/ext2fs.h>
#include "identifier.h"

PedDevice **_p_alldev;
PedPartition **_p_part_list;
long long CYLINDER_BOUNDARY_OVERHEAD = 0;
int _N_RAW_PARTS = 0;
_resizable_partition resizable_partitions[64];
_hole holes[64];
_hole replazables[64];
char **luser_index;

int _n_primary_parts = 0;
int _n_logical_parts = 0;
int _n_free_parts = 0;
int _n_ext_parts = 0;
int _n_win_parts = 0;
int _n_lin_parts = 0;
int _n_misc_parts = 0;

static char *luser_table[] = {
    "Windows 9x",
    "Windows NT/XP",
    "FAT32 Data",
    "Generic Linux",
    "Unknown",
    "Swap"
};

#define LUSER_WIN9X 0
#define LUSER_WINXP 1
#define LUSER_DATA 2
#define LUSER_LINUX 3
#define LUSER_UNKNOW 4
#define LUSER_SWAP 5

long long _USURPED_SPACE = 0;

 /* A couple of helpers */

int _p_linPart(PedFileSystemType * tofs)
{
    int status = 0;

    if (tofs == NULL)
	return status;

    if (strstr(tofs->name, "ext2") != NULL)
	status = 1;
    if (strstr(tofs->name, "reiserfs") != NULL)
	status = 1;
    if (strstr(tofs->name, "ext3") != NULL)
	status = 1;
    if (strstr(tofs->name, "xfs") != NULL)
	status = 1;
    if (strstr(tofs->name, "jfs") != NULL)
	status = 1;
    return status;

}

int _p_winPart(PedFileSystemType * tofs)
{
    int status = 0;

    if (tofs == NULL)
	return status;

    if (strstr(tofs->name, "fat") != NULL)
	status = 1;
    if (strstr(tofs->name, "ntfs") != NULL)
	status = 1;
    return status;

}

int _p_swapPart(PedFileSystemType * tofs)
{
    int status = 0;

    if (tofs == NULL)
	return status;

    if (strstr(tofs->name, "linux-swap") != NULL)
	status = 1;

    return status;

}

 /* 

    Function :_p_search_drives

    Search for the the current drives in system
    and get descriptions

  */

int _p_search_drives()
{
    PedDevice *_p_dev;
    int c = 0;

    T_FUNC_IN xprint("%s", _i18n("Analizying disk(s) on system\n"));
    fflush(stdout);
    ped_device_probe_all();

    _p_dev = ped_device_get_next(NULL);
    printf("%s", _i18n("Detected devices:\n"));
    while (_p_dev != NULL) {
	_DRIVE_LIST[c] = (char *) malloc(256);
	_DRIVE_LIST_NAMES[c] = (char *) malloc(256);
	sprintf(_DRIVE_LIST[c], "%s - %s", _p_dev->path, _p_dev->model);
	strcpy(_DRIVE_LIST_NAMES[c], _p_dev->path);
	printf("LD#%s:%d|", _i18n("Media"), c);
	printf("%s:%s|", _i18n("Model"), _p_dev->model);
	printf("%s:%s|", _i18n("Path"), _p_dev->path);
	printf("%s:%d|", _i18n("Type"), _p_dev->type);
	printf("%s:%lld|", _i18n("Sectors"), _p_dev->length);
	printf("%s:%u|", _i18n("SectorSize"), _p_dev->sector_size);
	printf("%s:%lld\n", _i18n("Total"),
	       _p_dev->length * _p_dev->sector_size);
	_p_dev = ped_device_get_next(_p_dev);
	c++;
    }
    printf("%s:%d\n", _i18n("Total devices"), c);

    _p_alldev = (PedDevice **) malloc(sizeof(PedDevice *) * c);
    _p_dev = ped_device_get_next(NULL);
    c = 0;
    while (_p_dev != NULL) {
	_p_alldev[c] = _p_dev;
	_p_dev = ped_device_get_next(_p_dev);
	c++;
    }
    _N_DRIVES = c;

    /*if (_SELECTED_DRIVE[0] == '\0')
       strcpy (&_SELECTED_DRIVE[0], _p_alldev[0]->path); */

    T_FUNC_OUT;

    return 1;

}

 /*

    Function :_p_select_drive

    Select a drive by name

  */

int _p_select_drive(char *name)
{

    int i;

    T_FUNC_IN
	xprint("%s %s (%d)...", _i18n("Selecting drive"), name, _N_DRIVES);

    for (i = 0; i < _N_DRIVES; i++)
	if (strcmp(name, _p_alldev[i]->path) == 0) {
	    _N_SEL_DRIVE = i;

	}

    if ((_SELECTED_DRIVE[0] == '\0') && (_N_SEL_DRIVE > 0)) {
	strcpy(&_SELECTED_DRIVE[0], _p_alldev[0]->path);
	_N_SEL_DRIVE = 0;

    }

    /* If no drives were detected */

    xprint("ok %s (%d)\n", _SELECTED_DRIVE, _N_SEL_DRIVE);

    if (_N_SEL_DRIVE < 0)
	return 0;

    CYLINDER_BOUNDARY_OVERHEAD =
	_p_alldev[_N_SEL_DRIVE]->hw_geom.heads *
	_p_alldev[_N_SEL_DRIVE]->hw_geom.sectors *
	// _p_alldev[_N_SEL_DRIVE]->heads * _p_alldev[_N_SEL_DRIVE]->sectors *
	_p_alldev[_N_SEL_DRIVE]->sector_size;

    T_FUNC_OUT;;

    return 1;

}

char *_p_part_type_string(int type)
{

    if (type == 0)
	return _i18n("Primary Partition     ");
    else if (type == PED_PARTITION_LOGICAL)
	return _i18n("Logical Partition     ");
    else if (type == (PED_PARTITION_EXTENDED))
	return _i18n("Extended Partition    ");
    else if (type == (PED_PARTITION_FREESPACE))
	return _i18n("Free Space            ");
    else if (type == (PED_PARTITION_METADATA))
	return _i18n("Metadata Space        ");
    else if (type == (PED_PARTITION_METADATA | PED_PARTITION_LOGICAL))
	return _i18n("Logical Metadata Space");
    else if (type == (PED_PARTITION_FREESPACE | PED_PARTITION_LOGICAL))
	return _i18n("Logical Free Space    ");

}

 /* 

    Function :_p_anlz_parts

    Analyces partitions on a drive

  */

int _p_anlz_parts(_N_DRIVE)
{

    int i = 0;
    int j = 1;

    PedDisk *_p_disk;
    PedDiskType *_p_type;
    PedPartition *_p_part_h;
    PedFileSystemType *_p_part_fs;
    PedGeometry *_p_part_geo;



    /*
       PED_PARTITION_LOGICAL               = 0x01,
       PED_PARTITION_EXTENDED              = 0x02,
       PED_PARTITION_FREESPACE     = 0x04,
       PED_PARTITION_METADATA              = 0x08  

     */

    T_FUNC_IN;

    if (_N_DRIVE < 0) {
	xprint("%s", _i18n("No drive selected...\n"));
	return -1;
    }

    xprint("%s %d... ", _i18n("Analyzing partitions on drive n"),
	   _N_DRIVE);

    _p_disk = ped_disk_new(_p_alldev[_N_DRIVE]);
    if (_p_disk == NULL) {
	xprint("%s\n", _i18n("Disk empty without partition table"));
	xfprint("AA#%s\n",
		_i18n
		("Disk empty without partition table or unrecognised disk label"));
	_DISK_STATUS = DISK_CLEAN;
	return 1;
    }

    _p_type = (PedDiskType *) _p_disk->type;
    xprint("%s:%s\n", _i18n("Partition table type"), _p_type->name);

    _p_part_h = ped_disk_next_partition(_p_disk, NULL);
    i = 0;
    while (_p_part_h != NULL) {
	_p_part_h = ped_disk_next_partition(_p_disk, _p_part_h);
	i++;
    }

    xprint("#%s:%d\n", _i18n("Total raw partitions"), i);
    _p_part_list = (PedPartition **) malloc(sizeof(PedPartition) * i);

    luser_index = (char **) malloc(sizeof(char *) * (i + 1));

    _N_RAW_PARTS = i;
    _p_part_h = ped_disk_next_partition(_p_disk, NULL);
    i = 0;
    xprint("%s\t%s\t\t\t%s\t%s\n", _i18n("Number"), _i18n("Type"),
	   _i18n("Filesystem"), _i18n("Geometry"));
    while (_p_part_h != NULL) {
	_p_part_list[i] = _p_part_h;

	if (_p_part_h->num > 0)
	    xprint("#%d\t", _p_part_h->num);
	else
	    xprint("%d\t", _p_part_h->num);

	xprint("0x%x:%s\t", _p_part_h->type,
	       _p_part_type_string(_p_part_h->type));

	if (_p_part_h->fs_type != NULL)
	    xprint("%s\t", _p_part_h->fs_type->name);
	else
	    xprint("%s\t", _i18n("NOFS"));

	xprint("%lld - %lld (%lld)\n", _p_part_h->geom.start,
	       _p_part_h->geom.end, _p_part_h->geom.length);

	/* Some prelogic */
	if ((_p_part_h->num > 0) && (_p_part_h->type == 0))
	    _n_primary_parts++;
	if ((_p_part_h->num > 0) && (_p_part_h->type == 1))
	    _n_logical_parts++;
	if ((_p_part_h->num > 0) && (_p_part_h->type == 2))
	    _n_ext_parts++;

	if ((_p_part_h->num > 0) && (_p_linPart(_p_part_h->fs_type)))
	    _n_lin_parts++;
	if ((_p_part_h->num > 0) && (_p_winPart(_p_part_h->fs_type)))
	    _n_win_parts++;

	if ((_p_part_h->type == 4) || (_p_part_h->type == 5)) {
	    _n_free_parts++;
	    _DISK_STATUS = _DISK_STATUS | DISK_FREESPACE;
	    if ((_p_part_h->geom.length *
		 _p_alldev[_N_DRIVE]->sector_size) > _MIN_SPACE)
		_DISK_STATUS = _DISK_STATUS | DISK_FREESPACE_CT;
	}

	/* Partition identifying */

	if ((_p_part_h->num > 0) && (_p_linPart(_p_part_h->fs_type))) {
	    luser_index[i] = luser_table[LUSER_LINUX];
	    xprint("Type %s\n", luser_index[i]);

	} else if ((_p_part_h->num > 0)
		   && (_p_swapPart(_p_part_h->fs_type))) {
	    luser_index[i] = luser_table[LUSER_SWAP];
	    xprint("Type %s\n", luser_index[i]);

	}

	else if ((_p_part_h->num > 0) && (_p_winPart(_p_part_h->fs_type))) {
	    luser_index[i] =
		giveName(unix_device_name
			 (_p_disk->dev->path, _p_part_h->num));
	    xprint("Type %s\n", luser_index[i]);
	} else if (_p_part_h->num > 0)
	    luser_index[i] = NULL;



	_p_part_h = ped_disk_next_partition(_p_disk, _p_part_h);
	i++;

    }

    printf("VV#%s:%d + %d (%d) \n", _i18n("Total primary partitions"),
	   _n_primary_parts, _n_ext_parts,
	   _n_primary_parts + _n_ext_parts);
    _n_primary_parts += _n_ext_parts;
    printf("VV#%s:%d\n", _i18n("Total extended partitions"), _n_ext_parts);
    printf("VV#%s:%d\n", _i18n("Total logical partitions"),
	   _n_logical_parts);
    printf("VV#%s:%d\n", _i18n("Total free spaces"), _n_free_parts);
    printf("VV#%s:%d\n", _i18n("Total linux partitions"), _n_lin_parts);
    printf("VV#%s:%d\n", _i18n("Total win partitions"), _n_win_parts);

    if (_n_free_parts < 1)
	_DISK_STATUS = _DISK_STATUS | DISK_FULL;
    else
	_DISK_STATUS = _DISK_STATUS | DISK_FREESPACE;

    if ((_n_primary_parts > 3) && (_n_ext_parts < 1))
	_DISK_STATUS = _DISK_STATUS | DISK_UNPART;

    if ((_n_primary_parts > 3) && (_n_ext_parts > 0))
	_DISK_STATUS = _DISK_STATUS | DISK_JUSTLOGICAL;

    if (_n_lin_parts > 0)
	_DISK_STATUS = _DISK_STATUS | DISK_LIN;

    if (_n_win_parts > 0)
	_DISK_STATUS = _DISK_STATUS | DISK_WIN;

    if ((_n_primary_parts + _n_ext_parts + _n_logical_parts) == 0)
	_DISK_STATUS = _DISK_STATUS | DISK_CLEAN;

    /*if ((_p_alldev[_N_DRIVE]->length) * (_p_alldev[_N_DRIVE]->sector_size) <
       _MIN_SPACE)
       _DISK_STATUS = DISK_UNKNOWN; */

    if ((_JUSTLOGICAL == 1))
	_DISK_STATUS = _DISK_STATUS | DISK_JUSTLOGICAL;

    T_FUNC_OUT;

    return 1;
}

/* 

    Function :_p_nextFree

    When resizing a partition, guess wich id will have

  */

int _p_nextFree(int resized)
{
    int t, i;
    int n = 0;
    if (resized < 5) {
	/* We've resized a primary partition */
	for (i = 1; i <= 4; i++) {
	    n = i;
	    for (t = 0; t < _N_RAW_PARTS; t++) {
		if (_p_part_list[t]->num == n) {
		    /* already Assigned */
		    n = 0;
		    break;
		}
	    }
	    if (n > 0)
		return n;
	}

	return n;
    } else {
	/* We've resized a logical partition */
	for (i = 5; i <= 16; i++) {
	    n = i;
	    for (t = 0; t < _N_RAW_PARTS; t++) {
		if (_p_part_list[t]->num == n) {
		    /* already Assigned */
		    n = 0;
		    break;
		}
	    }
	    if (n > 0)
		return n;
	}
	return n;
    }

}
int _p_freeId()
{
    int t, i;
    int n = 0;
    int total = 0;

    for (i = 1; i <= 4; i++) {
	n = i;
	for (t = 0; t < _N_RAW_PARTS; t++) {
	    if (_p_part_list[t]->num == n) {
		/* already Assigned */
		total++;
		break;
	    }
	}
    }

    return 4 - total;

}

int _p_nextFreeOver(int resized)
{
    int t, i;
    int n = 0;
    if (resized < 4) {
	/* We've resized a primary partition */
	for (i = 1; i <= 4; i++) {
	    n = i;
	    for (t = 0; t < _N_RAW_PARTS; t++) {
		if (_p_part_list[t]->num == n) {
		    /* already Assigned */
		    n = 0;
		    break;
		}
	    }
	    if ((n > 0) && (n > resized))
		return n;
	}
	return n;
    } else {
	/* We've resized a logical partition */
	for (i = 5; i <= 16; i++) {
	    n = i;
	    for (t = 0; t < _N_RAW_PARTS; t++) {
		if (_p_part_list[t]->num == n) {
		    /* already Assigned */
		    n = 0;
		    break;
		}
	    }
	    if ((n > 0) && (n > resized))
		return n;
	}
	return n;
    }

}

int _p_findHole()
{
    int i = 0;
    int n_holes = 0;

    for (i = 0; i < _N_RAW_PARTS; i++) {

	if (_p_cFlag(DISK_JUSTLOGICAL) && (_p_part_list[i]->type != 5)) {
	    xprint("%s\n", _i18n("Disabled by DISK_JUSTLOGICAL"));
	    continue;
	}
	if ((_p_part_list[i]->type == 4) || (_p_part_list[i]->type == 5))
	    /* Partition with free space */
	    if ((_p_part_list[i]->geom.length *
		 _p_alldev[_N_SEL_DRIVE]->sector_size) > _MIN_SPACE) {
		holes[n_holes].partition_index = i;
		holes[n_holes].startSEC = _p_part_list[i]->geom.start;
		holes[n_holes].endSEC = _p_part_list[i]->geom.end;
		holes[n_holes].sizeSEC = _p_part_list[i]->geom.length;
		holes[n_holes].startMB =
		    (holes[n_holes].startSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		holes[n_holes].endMB =
		    (holes[n_holes].endSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		holes[n_holes].sizeMB =
		    (holes[n_holes].sizeSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		strcpy(holes[n_holes].major, &_SELECTED_DRIVE[0]);
		holes[n_holes].minor = _p_part_list[i]->num;
		if ((_p_part_list[i]->type & PED_PARTITION_LOGICAL) ==
		    PED_PARTITION_LOGICAL) {
		    strcpy(holes[n_holes].type, "logical");
		    holes[n_holes].next_free = _p_nextFree(5);
		} else if ((_p_part_list[i]->type & PED_PARTITION_LOGICAL)
			   == PED_PARTITION_NORMAL) {
		    strcpy(holes[n_holes].type, "primary");
		    holes[n_holes].next_free = _p_nextFree(0);
		}

		holes[n_holes].original = _p_part_list[i];

		n_holes++;

	    }

    }
    return n_holes;

}

void def_handler(PedTimer * timer, void *context)
{


    if (!DprogressBar(_i18n("Checking partitions"), timer->frac))
	xprint("%s %f\b", _i18n("Checking partitions"), timer->frac);

}

int _p_checkResizability(int i, int x, char force_index)
{

    static int c = -1;
    long long gained = 0;
    long long resntfs = 0;
    PedFileSystem *aux;
    PedGeometry *proposal;
    PedConstraint *propo;
    char device_name[256];

    void *context = NULL;
    PedTimerHandler *handler;
    PedTimer *progress;
    char message[1024];

    char SPARSE_SUPER = 0;


    ext2_filsys ext_h;

    int status;

    T_FUNC_IN;

    /* Iniciamos index */
    if (c == -1)
	c = x;
    if (force_index == 1)
	c = x;


    xprint("[%s] [%d] Checking if can be resized (%s%d)\n", __FILE__,
	   __LINE__, _p_part_list[i]->disk->dev->path,
	   _p_part_list[i]->num);

    if (!((_p_part_list[i]->type == 0) || (_p_part_list[i]->type == 1)))
	return 0;

    if (_p_part_list[i]->fs_type != NULL) {
	if (_p_part_list[i]->fs_type->name != NULL) {
	    if (strcmp("linux-swap", _p_part_list[i]->fs_type->name) == 0)
		return 0;
	}
    }



    if (_p_cFlag(DISK_JUSTLOGICAL) && (_p_part_list[i]->type != 1)) {
	xprint("%s\n", _i18n("Disabled by DISK_JUSTLOGICAL"));
	return 0;
    }



    xprint("%s%d:%s\n", _p_part_list[i]->disk->dev->path,
	   _p_part_list[i]->num, _i18n("Checking for errors.."));

    if (_p_part_list[i]->fs_type != NULL) {
	sprintf(message, "%s %s%d (%s)   ", _i18n("Checking partition..."),
		_p_part_list[i]->disk->dev->path, _p_part_list[i]->num,
		_p_part_list[i]->fs_type->name);
    } else {
	sprintf(message, "%s %s%d (%s)   ", _i18n("Checking partition..."),
		_p_part_list[i]->disk->dev->path, _p_part_list[i]->num,
		"unknown");
    }






    /* SPARSE_SUPER EXT3 Workaround   */
    sprintf(device_name, "%s%d", _p_part_list[i]->disk->dev->path,
	    _p_part_list[i]->num);
    if (ext2fs_open
	(device_name, EXT2_FLAG_RW, 0, 0, unix_io_manager, &ext_h)
	== 0) {
	xprint("\next2: %s %s\n", device_name,
	       _i18n("ext2 library report ext filesystem..."));
	if (ext2fs_test_valid(ext_h) == 0) {
	    xprint("%s %d\n", _i18n("Seems to be valid. Blocksize"),
		   ext_h->blocksize);
	    // Let's check for superblock flags 
	    xprint("%s %d\n", _i18n("Superblock flags"),
		   ext_h->super->s_feature_ro_compat);
	    if (EXT2_FEATURE_RO_COMPAT_SPARSE_SUPER
		&& ext_h->super->s_feature_ro_compat ==
		EXT2_FEATURE_RO_COMPAT_SPARSE_SUPER) {
		xprint("%s\n",
		       _i18n
		       ("Trouble, sparse_super is enabled here. No way to resize this safely"));
		SPARSE_SUPER = 1;
	    } else {
		xprint("%s\n",
		       _i18n
		       ("sparse_super is disabled here. parted driver will care"));
		SPARSE_SUPER = 0;
	    }
	} else {
	    xprint("%s\n",
		   _i18n("Seems to be invalid. Will try parted driver"));
	}

    }

    if ((_p_part_list[i + 1]->type == 4)
	|| (_p_part_list[i + 1]->type == 5)) {
	xprint("There's a hole right here! %s\n",
	       _p_part_list[i + 1]->disk->dev->path);
	_USURPED_SPACE =
	    (_p_part_list[i + 1]->geom.length *
	     _p_part_list[i + 1]->disk->dev->sector_size);
    } else
	_USURPED_SPACE = 0;

    resizable_partitions[c].USURPED = _USURPED_SPACE;

    /* Check if this filesystem is suported */
    if (SPARSE_SUPER == 0) {
	DprogressBar(message, 0);
	aux = ped_file_system_open(&_p_part_list[i]->geom);
	if (aux != NULL) {
	    handler = (PedTimerHandler *) (&def_handler);
	    progress =
		ped_timer_new((PedTimerHandler *) (&def_handler), context);
	    status = ped_file_system_check(aux, progress);
	    DprogressBar(message, 2.0f);
	    ped_timer_destroy(progress);
	}

    } else {
	/* Sparse super code here */
	long long ext2_size;
	long long ext2_free;

	ext2_size =
	    ((long long) ext_h->super->s_blocks_count * ext_h->blocksize);
	ext2_free =
	    ((long long) ext_h->super->s_free_blocks_count *
	     ext_h->blocksize);


	xprint("%s %lld (form total %d blocks) + Adjacent hole: %lld ",
	       _i18n("Be freed"), ext2_free,
	       ext_h->super->s_free_blocks_count, _USURPED_SPACE);
	xprint("%s %lld\n", _i18n("Required"), _MIN_SPACE);

	if ((ext2_free + _USURPED_SPACE) > _MIN_SPACE) {
	    resizable_partitions[c].free_space_gained = ext2_free -
		CYLINDER_BOUNDARY_OVERHEAD - _RESIZE2FS_OVERHEAD;

	    resizable_partitions[c].partition_index = i;
	    resizable_partitions[c].new_startMB = (double)
		(_p_part_list[i]->geom.start *
		 _p_part_list[i]->disk->dev->sector_size) /
		_MEGABYTE_FACTOR;
	    resizable_partitions[c].new_endMB = (double)
		(((_p_part_list[i]->geom.start +
		   _p_part_list[i]->geom.length) *
		  _p_part_list[i]->disk->dev->sector_size) -
		 (_MIN_SPACE + _RESIZE2FS_OVERHEAD +
		  CYLINDER_BOUNDARY_OVERHEAD)) / _MEGABYTE_FACTOR;
	    sprintf(resizable_partitions[c].major, "%s",
		    _p_part_list[i]->disk->dev->path);
	    resizable_partitions[c].minor = _p_part_list[i]->num;
	    resizable_partitions[c].driver = DRIVER_RESIZE2FS;

	    resizable_partitions[c].new_startSEC =
		_p_part_list[i]->geom.start;


	    resizable_partitions[c].new_endSEC =
		((_p_part_list[i]->geom.start +
		  _p_part_list[i]->geom.length) *
		 _p_part_list[i]->disk->dev->sector_size - _MIN_SPACE -
		 _RESIZE2FS_OVERHEAD -
		 CYLINDER_BOUNDARY_OVERHEAD) /
		_p_part_list[i]->disk->dev->sector_size;
	    resizable_partitions[c].new_endSEC =
		(long
		 long) (ceil(resizable_partitions[c].new_endSEC /
			     (CYLINDER_BOUNDARY_OVERHEAD /
			      _p_part_list[i]->disk->dev->sector_size)) *
			(CYLINDER_BOUNDARY_OVERHEAD /
			 _p_part_list[i]->disk->dev->sector_size));
	    xprint("Legacy calculation: (C/H/S) %d %d %d in %d\n",
		   _p_part_list[i]->disk->dev->hw_geom.cylinders,
		   _p_part_list[i]->disk->dev->hw_geom.heads,
		   _p_part_list[i]->disk->dev->hw_geom.sectors, c);
	    // _p_part_list[i]->disk->dev->cylinders,
	    // _p_part_list[i]->disk->dev->heads,
	    // _p_part_list[i]->disk->dev->sectors);


	    resizable_partitions[c].new_sizeSEC =
		resizable_partitions[c].new_endSEC -
		resizable_partitions[c].new_startSEC;
	    resizable_partitions[c].original = _p_part_list[i];
	    resizable_partitions[c].new_sizeMB =
		resizable_partitions[c].new_endMB -
		resizable_partitions[c].new_startMB;
	    resizable_partitions[c].next_free =
		_p_nextFree(resizable_partitions[c].partition_index);



	    xprint("%s %d\n", _i18n("Id to be assigned"),
		   resizable_partitions[c].next_free);

	    /*if (resizable_partitions[c].next_free == 0) {

	       return 0;
	       }
	     */
	    c++;

	    //DprogressBar(message, 2.0f);
	    //ped_timer_destroy(progress);

	    return 1;

	}
	return 0;



    }

    if (aux != NULL) {
	if (status) {

	    xprint("%s ", _i18n("OK"));
	    propo = ped_file_system_get_resize_constraint(aux);
	    if (propo) {
		/* Check mimimal size partition can be resize to */

		xprint("%s %lld  ... ", _i18n("Minimal size"),
		       propo->min_size);

		gained =
		    (_p_part_list[i]->geom.length -
		     propo->min_size) *
		    _p_part_list[i]->disk->dev->sector_size;
		xprint("%s %lld ", _i18n("Be freed"), gained);
		xprint("%s %lld\n", _i18n("Required"), _MIN_SPACE);

		if (gained + _USURPED_SPACE > _MIN_SPACE) {
		    /* Actions for good candidates */
		    proposal = ped_constraint_solve_max(propo);
		    xprint("%s (%d)\n", _i18n("Good candidate"), c);
		    resizable_partitions[c].free_space_gained =
			gained - _PARTED_OVERHEAD -
			CYLINDER_BOUNDARY_OVERHEAD;
		    resizable_partitions[c].partition_index = i;
		    resizable_partitions[c].new_startMB = (double)
			(_p_part_list[i]->geom.start *
			 _p_part_list[i]->disk->dev->sector_size) /
			_MEGABYTE_FACTOR;
		    resizable_partitions[c].new_endMB = (double)
			(((_p_part_list[i]->geom.start +
			   _p_part_list[i]->geom.length) *
			  _p_part_list[i]->disk->dev->sector_size) -
			 (_MIN_SPACE + _PARTED_OVERHEAD +
			  CYLINDER_BOUNDARY_OVERHEAD)) / _MEGABYTE_FACTOR;
		    sprintf(resizable_partitions[c].major, "%s",
			    _p_part_list[i]->disk->dev->path);
		    resizable_partitions[c].minor = _p_part_list[i]->num;
		    resizable_partitions[c].driver = DRIVER_PARTED;

		    resizable_partitions[c].new_startSEC =
			_p_part_list[i]->geom.start;
		    resizable_partitions[c].new_endSEC =
			((_p_part_list[i]->geom.start +
			  _p_part_list[i]->geom.length) *
			 _p_part_list[i]->disk->dev->sector_size -
			 _MIN_SPACE - _PARTED_OVERHEAD -
			 CYLINDER_BOUNDARY_OVERHEAD) /
			_p_part_list[i]->disk->dev->sector_size;
		    resizable_partitions[c].new_sizeSEC =
			resizable_partitions[c].new_endSEC -
			resizable_partitions[c].new_startSEC;
		    resizable_partitions[c].original = _p_part_list[i];
		    resizable_partitions[c].next_free =
			_p_nextFree(resizable_partitions[c].
				    partition_index);

		    xprint("%s %d\n", _i18n("Id to be assigned"),
			   resizable_partitions[c].next_free);
		    /* Don't mark it as resizable if is not id of same type free */
		    /*if ((resizable_partitions[c].next_free>4)&&(resizable_partitions[c].partition_index<5))
		       return 0;
		       else if ((resizable_partitions[c].next_free<5)&&(resizable_partitions[c].partition_index>4))
		       return 0; */
		    if (resizable_partitions[c].next_free == 0) {
			DprogressBar(message, 2.0f);
			return 0;
		    }

		    c++;

		    //DprogressBar(message, 2.0f);
		    //ped_timer_destroy(progress);

		    return 1;

		} else {
		    xprint("%s\n", _i18n("Bad candidate"));
		    DprogressBar(message, 2.0f);
		    return 0;
		}

	    } else {
		xprint("%s\n", _i18n("Unresizable"));
		DprogressBar(message, 2.0f);
		return 0;
	    }

	} else {
	    xprint("%s\n", _i18n("Not OK. Check this filesystem..."));
	    DprogressBar(message, 2.0f);

	    return 0;
	}
    } else {

	printf("Error code from libparted :%d\n", aux);
	xprint("%d %s %s%d", status,
	       _i18n("Filesystem not supported. Probing ntfsresize..."),
	       _p_part_list[i]->disk->dev->path, _p_part_list[i]->num);
	sprintf(&device_name[0], "%s%d", _p_part_list[i]->disk->dev->path,
		_p_part_list[i]->num);
	resntfs = test_resize(&device_name[0], _MIN_SPACE);
	gained =
	    ((_p_part_list[i]->geom.length *
	      _p_part_list[i]->disk->dev->sector_size) - (resntfs));

	xprint("%s: %lld (%.4f MiB)\n", _i18n("Gained"), gained,
	       (double) (gained / _MEGABYTE_FACTOR));
	if ((gained + _USURPED_SPACE > _MIN_SPACE) && (resntfs > 0)) {
	    /* Actions for good candidates */

	    xprint("%s (%d)\n", _i18n("Good candidate"), c);
	    resizable_partitions[c].free_space_gained =
		gained - _NFSRESIZE_OVERHEAD - CYLINDER_BOUNDARY_OVERHEAD;
	    resizable_partitions[c].partition_index = i;
	    resizable_partitions[c].new_startMB = (double)
		(_p_part_list[i]->geom.start *
		 _p_part_list[i]->disk->dev->sector_size) /
		_MEGABYTE_FACTOR;
	    resizable_partitions[c].new_endMB = (double)
		(((_p_part_list[i]->geom.start +
		   _p_part_list[i]->geom.length) *
		  _p_part_list[i]->disk->dev->sector_size) - (_MIN_SPACE +
							      _NFSRESIZE_OVERHEAD
							      +
							      CYLINDER_BOUNDARY_OVERHEAD))
		/ _MEGABYTE_FACTOR;
	    resizable_partitions[c].new_sizeMB =
		resizable_partitions[c].new_endMB -
		resizable_partitions[c].new_startMB;
	    sprintf(resizable_partitions[c].major, "%s",
		    _p_part_list[i]->disk->dev->path);
	    resizable_partitions[c].minor = _p_part_list[i]->num;
	    resizable_partitions[c].driver = DRIVER_NTFSRESIZE;
	    resizable_partitions[c].new_startSEC =
		_p_part_list[i]->geom.start;
	    resizable_partitions[c].new_endSEC =
		((_p_part_list[i]->geom.start +
		  _p_part_list[i]->geom.length) *
		 _p_part_list[i]->disk->dev->sector_size - _MIN_SPACE -
		 _NFSRESIZE_OVERHEAD -
		 CYLINDER_BOUNDARY_OVERHEAD) /
		_p_part_list[i]->disk->dev->sector_size;
	    resizable_partitions[c].new_endSEC =
		(long
		 long) (ceil(resizable_partitions[c].new_endSEC /
			     (CYLINDER_BOUNDARY_OVERHEAD /
			      _p_part_list[i]->disk->dev->sector_size)) *
			(CYLINDER_BOUNDARY_OVERHEAD /
			 _p_part_list[i]->disk->dev->sector_size));
	    xprint("Legacy calculation: (C/H/S) %d %d %d in %d\n",
		   _p_part_list[i]->disk->dev->hw_geom.cylinders,
		   _p_part_list[i]->disk->dev->hw_geom.heads,
		   _p_part_list[i]->disk->dev->hw_geom.sectors, c);
	    // _p_part_list[i]->disk->dev->cylinders,
	    // _p_part_list[i]->disk->dev->heads,
	    // _p_part_list[i]->disk->dev->sectors);

	    resizable_partitions[c].new_sizeSEC =
		resizable_partitions[c].new_endSEC -
		resizable_partitions[c].new_startSEC;
	    resizable_partitions[c].original = _p_part_list[i];
	    resizable_partitions[c].next_free =
		_p_nextFree(resizable_partitions[c].partition_index);

	    xprint("%s %d\n", _i18n("Id to be assigned"),
		   resizable_partitions[c].next_free);
	    /* Don't mark it as resizable if is not id of same type free */
	    /*if ((resizable_partitions[c].next_free>4)&&(resizable_partitions[c].partition_index<5))
	       return 0;
	       else if ((resizable_partitions[c].next_free<5)&&(resizable_partitions[c].partition_index>4))
	       return 0; */
	    if (resizable_partitions[c].next_free == 0) {

		return 0;
	    }
	    c++;
	    return 1;
	} else {
	    xprint("%s\n", _i18n("Failed"));
	    return 0;
	}

    }

    DprogressBar(message, 2.0f);
    T_FUNC_OUT;
    return 1;

}

int _p_findRes(int x)
{

    int i = 0;
    int j = 0;
    T_FUNC_IN;
    xprint("%s\n", _i18n("Checking for resizable partitions"));
    for (i = 0; i < _N_RAW_PARTS; i++) {

	if (_p_checkResizability(i, x, 0))
	    j++;


    }


    fflush(stdout);

    T_FUNC_OUT;
    return j;

}

 /* 

    Function :_p_anlz

    Search for the the current drives in system
    and get descriptions

  */

int _p_findReplazable(int j)
{
    int i = 0;
    int n_holes = 0;

    n_holes = j;
    xprint("%s ", _i18n("Checking if suitable to replace..."));
    for (i = 0; i < _N_RAW_PARTS; i++) {
	xprint("%d ", _p_part_list[i]->num);
	if (_p_linPart(_p_part_list[i]->fs_type))
	    /* Linux partition */
	    if ((_p_part_list[i]->geom.length *
		 _p_alldev[_N_SEL_DRIVE]->sector_size) > _MIN_SPACE) {
		/* Has the size */

		replazables[n_holes].partition_index = i;
		replazables[n_holes].startSEC =
		    _p_part_list[i]->geom.start;
		replazables[n_holes].endSEC = _p_part_list[i]->geom.end;
		replazables[n_holes].sizeSEC =
		    _p_part_list[i]->geom.length;
		replazables[n_holes].startMB =
		    (replazables[n_holes].startSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		replazables[n_holes].endMB =
		    (replazables[n_holes].endSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		replazables[n_holes].sizeMB =
		    (replazables[n_holes].sizeSEC *
		     _p_alldev[_N_SEL_DRIVE]->sector_size) /
		    _MEGABYTE_FACTOR;
		strcpy(replazables[n_holes].major, &_SELECTED_DRIVE[0]);
		replazables[n_holes].minor = _p_part_list[i]->num;
		if ((_p_part_list[i]->type & PED_PARTITION_LOGICAL) ==
		    PED_PARTITION_LOGICAL) {
		    strcpy(replazables[n_holes].type, "logical");
		    replazables[n_holes].next_free = _p_nextFree(5);
		} else if ((_p_part_list[i]->type & PED_PARTITION_LOGICAL)
			   == PED_PARTITION_NORMAL) {
		    strcpy(replazables[n_holes].type, "primary");
		    replazables[n_holes].next_free = _p_nextFree(0);
		}

		replazables[n_holes].original = _p_part_list[i];
		xprint("%s (%d) ", _i18n("Yes"),
		       replazables[n_holes].partition_index);
		n_holes++;

	    } else
		xprint("%s ", _i18n("No"));
	else
	    xprint("%s ", _i18n("No"));

    }

    return (n_holes - j);

}

int _p_anlz()
{

    char aux[2048];
    int op = -1;

    T_FUNC_IN;

    if (!_p_search_drives())
	return -1;


    if ((strlen(_SELECTED_DRIVE) == 0) && (_BE_INTERACTIVE == 1)) {
	op = DreadOption(_N_DRIVES, _DRIVE_LIST,
			 _i18n("Please select a drive"));

	if (op != 0)
	    op--;
	xprint("selected index %d\n", op);
	if (op > -1) {
	    strcpy(_SELECTED_DRIVE, _DRIVE_LIST_NAMES[op]);
	} else if (DreadLine(_i18n("Please select a drive"), aux))
	    strcpy(_SELECTED_DRIVE, aux);
    }

    if (!_p_select_drive(_SELECTED_DRIVE))
	return 0;

    if (!_p_anlz_parts(_N_SEL_DRIVE))
	return 0;

    T_FUNC_OUT;

    return 1;
}
