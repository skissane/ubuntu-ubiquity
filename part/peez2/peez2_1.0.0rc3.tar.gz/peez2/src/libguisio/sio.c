/***************************************************************************
 *   Copyright (C) 2005 by Augusto Beiro                                   *
 *   abeiro@activasistemas.com                                             *
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 *   This program is distributed in the hope that it will be useful,       *
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of        *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the         *
 *   GNU General Public License for more details.                          *
 *                                                                         *
 *   You should have received a copy of the GNU General Public License     *
 *   along with this program; if not, write to the                         *
 *   Free Software Foundation, Inc.,                                       *
 *   59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.             *
 ***************************************************************************/

#include <stdio.h>

const char nombre[] = "Standard Input/Output Front-End";
const char autor[] = "Augusto Beiro Salanova";
const char info[] = "Standard Input/Output Front-End";
const int version[3] = { 0, 0, 1 };
const int fecha[3] = { 31, 1, 2005 };
const char extension[] = "sio";

char sio_p_init = 0;

extern char *mostrar_autor(void)
{
    return (char *) &autor[0];
}
extern char *mostrar_nombre(void)
{
    return (char *) &nombre[0];
}
extern char *mostrar_info(void)
{
    return (char *) &info[0];
}
extern int *mostrar_version(void)
{
    return (int *) &version[0];
}
extern int *mostrar_fecha(void)
{
    return (int *) &fecha[0];
}
extern char *mostrar_extension(void)
{
    return (char *) &extension[0];
}

extern int readline(char *orig, char *res)
{

    printf("> %s :", orig);
    fgets(res, 1024, stdin);
    res[strlen(res) - 1] = '\0';

}

extern int progressbar(char *msg, float f)
{

    static int last = 0;
    int current = 0;

    current = ((int) (f * 100));

    if (f > 1) {
	printf("100%\n");
	sio_p_init = 0;
	return 1;
    } else if (sio_p_init == 0) {
	printf("%s (%):  %d ", msg, current);
	sio_p_init = 1;
    } else if ((current % 20 == 0) && (last != current)) {
	printf("%d  ", current);
	last = current;
    }
    fflush(stdout);
    return 1;

}

extern int select_option(int number, char **leyendas, char *prompt)
{

    int i = 0;
    char c;
    printf("%s:\n", prompt);
    for (i = 0; i < number; i++)
	printf("%d) %s\n", i + 1, leyendas[i]);

    while (1) {
	c = (c - 1 - 48);
	if ((c > -1) && (c < number))
	    return (c + 1);
	else
	    c = getchar();
    }

}

extern long long int limit(long long int min, long long max, char *prompt)
{

    int i = 0;
    char c;
    long long int res = 0;
    printf("%s:", prompt);
    printf(" ( %lld - %lld ) :", min, max);

    scanf("%lld", &res);
    if ((res >= min) && (res <= max))
	return res;
    else
	return 0;

}
