/***************************************************************************
                          argparse.c  -  description
                             -------------------
    begin                : mar ene 11 2005
    copyright            : (C) 2005 by Augusto Beiro
    email                : abeiro@activasistemas.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/

#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include "global.h"

int verbose_flag;
char _APP_ACTION = APP_ACTION_SHOW;
char *_FRONTEND_ID = NULL;
char DEFAULT_FRONTEND[5] = "sio";

char *OUT_FILE_NAME = NULL;
char OUT_FILE = -1;

char layout[1024];

char _NO_MAKE_PARTITIONS = 0;
char _JUSTLOGICAL = 0;
int _p_parse_args(int argc, char *argv[])
{

    static int verbose_flag;
    static int interactive;
    const char *textdomaindir;
    static struct option long_options[] = {
	/* These options set a flag. */

	/* These options don't set a flag.
	   We distinguish them by their indices. */
	{"device", required_argument, NULL, 'd'},
	{"action", required_argument, NULL, 'a'},
	{"frontend", required_argument, NULL, 'f'},
	{"output", required_argument, NULL, 'o'},
	{"locale", required_argument, NULL, 'l'},
	{"min", required_argument, NULL, 'm'},
	{"max", required_argument, NULL, 'M'},
	{"scheme", required_argument, NULL, 's'},
	{"verbose", no_argument, &verbose_flag, 'v'},
	{"interactive", no_argument, &interactive, 'i'},
	{"yestoall", no_argument, &interactive, 'y'},
	{"justlogical", no_argument, &interactive, 'j'},
	{NULL, 0, NULL, 0}
    };
    int option_index = 0;
    int c = 0;

    _FRONTEND_ID = &DEFAULT_FRONTEND[0];

    c = getopt_long(argc, argv, "-d:a:f:o:l:m:M:s:viyj", long_options,
		    &option_index);
    while (c != -1) {
	switch (c) {

	case 'd':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }

	    printf("%s %s\n", _i18n("Specified device"), optarg);
	    strcpy(&_SELECTED_DRIVE[0], optarg);
	    break;
	case 'a':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }

	    printf("%s %s...", _i18n("Specified action"), optarg);
	    if (strstr(optarg, "show")) {
		_APP_ACTION = APP_ACTION_SHOW;
		printf("Ok\n");
	    } else if (strstr(optarg, "wizard")) {
		_APP_ACTION = APP_ACTION_WIZARD;

		printf("Ok\n");
	    } else if (strstr(optarg, "validate")) {
		_APP_ACTION = APP_ACTION_VALIDATE;
		printf("Ok\n");
	    }
	    break;
	case 'f':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }

	    _FRONTEND_ID = optarg;
	    printf("%s %s...", _i18n("Specified frontend"), _FRONTEND_ID);

	    break;
	case 'o':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }
	    OUT_FILE = 1;
	    OUT_FILE_NAME = optarg;
	    printf("%s %s...", _i18n("Output commands"), OUT_FILE_NAME);

	    break;

	case 'l':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }
	    textdomaindir = bindtextdomain("peez2", optarg);
	    xprint("Reusing domain dir '%s'.\n", textdomaindir);
	    break;

	case 'm':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }
	    _MIN_SPACE = (long long) atol(optarg) * 1024 * 1024;
	    xprint("Minimal space requested  '%lld' Bytes.\n", _MIN_SPACE);
	    break;


	case 'M':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }
	    _MAX_SPACE = (long long) atol(optarg) * 1024 * 1024;
	    xprint("Maximal space requested  '%lld' Bytes.\n", _MAX_SPACE);
	    break;

	case 's':
	    if (optarg == NULL) {
		printf("%s\n", _i18n("Wrong argument"));
		break;
	    }
	    strcpy(layout, optarg);
	    printf("Specified layout '%s' - ", layout);
	    int i = 0;
	    char *j;
	    char *p;
	    p = &layout[0];
	    while (j = strtok(p, ":")) {
		_LAYOUT[i] = (long long int) atoi(j);

		p = NULL;
		printf("'%lld' MiB : ", _LAYOUT[i]);
		i++;
	    }
	    xprint("\n");


	    break;
	case 'v':

	    printf("%s\n", _i18n("Verbose option activated"));
	    _BE_VERBOSE = 1;
	    break;
	case 'i':

	    printf("%s\n", _i18n("Interactive option activated"));
	    _BE_INTERACTIVE = 1;
	    break;

	case 'y':
	    printf("%s\n", _i18n("Yes"));
	    break;

	case 'j':
	    printf("%s\n", _i18n("Just Logical Partitions"));
	    _JUSTLOGICAL = 1;
	    break;
	}

	c = getopt_long(argc, argv, "-d:a:f:o:l:m:M:s:viyj", long_options,
			&option_index);

    }
    int i = 0;
    if (_LAYOUT[i] != 0) {
	_MIN_SPACE = 0;

	while (_LAYOUT[i] != 0) {
	    _MIN_SPACE += (_LAYOUT[i] * 1024 * 1024);
	    i++;
	}

	_MAX_SPACE = _MIN_SPACE;
	_NO_MAKE_PARTITIONS = 1;
	xprint("Minimal/Maximal space overrided  '%lld' Bytes.\n",
	       _MIN_SPACE);
    }

    return 1;

}
